<?php
	session_start();
    $amount=strtok($_POST['amount'],'.');
    if($_POST['currencies']=='Rial')    
		$amount = $amount/10;
		
// Security
$sec = uniqid();
$md = md5($sec.'vm');
// Security

$callBackUrl = $_POST['systemurl'].'/modules/gateways/callback/sn.php?check='.$md.'&sec='.$sec;

// Start WebService
$data_string = json_encode(array(
'pin'=> $_POST['merchantID'],
'price'=> $amount,
'callback'=> $callBackUrl ,
'order_id'=> $_POST['invoiceid'],
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$_SESSION[$sec] = [
	'price'=>$amount ,
	'order_id'=> $_POST['invoiceid'] ,
]; // SET Session

$ch = curl_init('https://developerapi.net/api/v1/index/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);

// End WebService

if(!empty($json['result']) AND $json['result'] == 1) //Verify
{
		
		$_SESSION[$sec]['au'] = $json['au']; //SET AU Session
		
	
		echo "<div style='display:none'>{$json['form']}</div>Please wait ... <script language='javascript'>document.payment.submit(); </script>"; //Send To Bank
		
	}
	else
	{
		echo '<meta charset=utf-8><pre>';
		$res = $json['msg'];
		print_r($res);
		die;
	}
?>