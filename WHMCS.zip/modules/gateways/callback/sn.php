<?php

session_start();

	error_reporting(0);
	
	if(file_exists('../../../init.php'))
	{
		define( 'WHMCSDBCONNECT', true );
		require( '../../../init.php' );
	
	}else{
		
		require("../../../dbconnect.php");
	}
	
    include('../../../includes/functions.php');
    include('../../../includes/gatewayfunctions.php');
    include('../../../includes/invoicefunctions.php');

    $gatewaymodule = 'sn'; 

    $GATEWAY = getGatewayVariables($gatewaymodule);
    if (!$GATEWAY['type']) die('Module Not Activated'); 
    
   
    if(empty($_GET['sec']) or empty($_GET['check'])) //Check Security
	die('Security Error !!!');
	
// Security
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');
$mdurl=$_GET['check'];
// Security
	
if($mdback == $mdurl) // Check Security
{
		
//get data from session
$transData = $_SESSION[$sec]; // Session
		
$au=$transData['au']; // Session

	
if(empty($transData['price']))
die('Price Error !!!');

$invoiceid=$transData['order_id'];
$invoiceid = checkCbInvoiceID($invoiceid,$GATEWAY['name']); 

checkCbTransID($transid); 
$amount = $transData['price'];
   
	

    
if($GATEWAY['Currencies']=='Rial')    
$amount = $amount*10;
$fee = 0;
    
    
// Start WebService
    $bank_return = $_POST + $_GET ;
   $data_string = json_encode(array (
'pin' => $GATEWAY['merchantID'],
'price' => $amount,
'order_id' => $invoiceid,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/index/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);

// End WebService
                    //result
                    $json = json_decode($result,true);
                    if($json['result'] == 1) //Verify
                    {
                  
                    
        addInvoicePayment($invoiceid,$au,$amount,$fee,$gatewaymodule); 
        logTransaction($GATEWAY['name'],$_POST,'Successful'); 
    } 
	else 
	{
        logTransaction($GATEWAY['name'],$_POST,'Unsuccessful'); 
    }
	$url = $CONFIG['SystemURL'].'/viewinvoice.php?id='.$invoiceid;
die("<script>window.location='$url';</script>");
    header('Location: '.$CONFIG['SystemURL'].'/viewinvoice.php?id='.$invoiceid);
}else{
 die('Security Error !!!');
}	
    
?>